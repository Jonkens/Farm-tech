<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenida | Sistema Ganadero</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e9edf2 100%);
        }
        .card-hover:hover {
            transform: translateY(-5px);
            transition: all 0.3s ease;
            box-shadow: 0 20px 25px -12px rgba(0,0,0,0.15);
        }
    </style>
</head>
<body class="font-sans antialiased">
    <div class="container mx-auto px-6 py-12">
        <!-- Encabezado de bienvenida -->
        <div class="text-center mb-12">
            <h1 class="text-4xl font-extrabold text-gray-800 mb-3">Bienvenido al Sistema de Producción Ganadera</h1>
            <p class="text-xl text-gray-600">Gestiona tu hato con tecnología de punta y datos en tiempo real</p>
            <div class="w-24 h-1 bg-green-500 mx-auto mt-4 rounded-full"></div>
        </div>

        <!-- Tarjetas de calidad destacada -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div class="bg-white rounded-2xl shadow-lg overflow-hidden card-hover">
                <div class="bg-blue-50 p-4 flex justify-center">
                    <i class="fas fa-tint text-5xl text-blue-500"></i>
                </div>
                <div class="p-6">
                    <h3 class="text-2xl font-bold text-gray-800 mb-2">Leche de la más alta calidad</h3>
                    <p class="text-gray-600">Nuestro sistema de ordeño y monitoreo garantiza leche con estándares internacionales. La leche producida es rica en proteínas, libre de antibióticos y con trazabilidad completa desde el establo hasta el consumidor. Cada vaca es evaluada diariamente para mantener una producción láctea óptima y saludable.</p>
                </div>
            </div>
            <div class="bg-white rounded-2xl shadow-lg overflow-hidden card-hover">
                <div class="bg-red-50 p-4 flex justify-center">
                    <i class="fas fa-drumstick-bite text-5xl text-red-500"></i>
                </div>
                <div class="p-6">
                    <h3 class="text-2xl font-bold text-gray-800 mb-2">Carne fresca y sustentable</h3>
                    <p class="text-gray-600">La carne que producimos proviene de animales criados en libertad, con alimentación balanceada y sin estrés. El resultado es una carne tierna, jugosa y con alto valor nutricional. Nuestro proceso de engorde controlado asegura cortes premium y una huella ambiental reducida.</p>
                </div>
            </div>
            <div class="bg-white rounded-2xl shadow-lg overflow-hidden card-hover">
                <div class="bg-yellow-50 p-4 flex justify-center">
                    <i class="fas fa-egg text-5xl text-yellow-600"></i>
                </div>
                <div class="p-6">
                    <h3 class="text-2xl font-bold text-gray-800 mb-2">Huevos de corral con sabor auténtico</h3>
                    <p class="text-gray-600">Nuestras gallinas campesinas producen huevos de cáscara firme y yema anaranjada intensa, ricos en omega-3 y vitaminas. La alimentación natural y el acceso a pastizales garantizan un producto fresco, libre de químicos y con el mejor sabor tradicional.</p>
                </div>
            </div>
        </div>

        <!-- Sección extendida de beneficios -->
        <div class="bg-white rounded-2xl shadow-md p-8 mb-12">
            <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">Compromiso con la excelencia</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="flex items-start gap-4">
                    <i class="fas fa-check-circle text-green-600 text-2xl mt-1"></i>
                    <div>
                        <h4 class="font-semibold text-xl">Trazabilidad total</h4>
                        <p class="text-gray-600">Desde el nacimiento hasta la comercialización, cada animal tiene un registro completo: salud, alimentación, medicamentos y rendimiento.</p>
                    </div>
                </div>
                <div class="flex items-start gap-4">
                    <i class="fas fa-chart-line text-blue-600 text-2xl mt-1"></i>
                    <div>
                        <h4 class="font-semibold text-xl">Monitoreo en tiempo real</h4>
                        <p class="text-gray-600">Sensores y análisis diarios te permiten tomar decisiones oportunas para maximizar la producción y el bienestar animal.</p>
                    </div>
                </div>
                <div class="flex items-start gap-4">
                    <i class="fas fa-leaf text-green-700 text-2xl mt-1"></i>
                    <div>
                        <h4 class="font-semibold text-xl">Prácticas sostenibles</h4>
                        <p class="text-gray-600">Manejo de residuos, uso eficiente del agua y pastoreo rotativo para cuidar el ambiente.</p>
                    </div>
                </div>
                <div class="flex items-start gap-4">
                    <i class="fas fa-trophy text-yellow-600 text-2xl mt-1"></i>
                    <div>
                        <h4 class="font-semibold text-xl">Premios a la calidad</h4>
                        <p class="text-gray-600">Reconocidos a nivel regional por la excelencia de nuestros lácteos y cárnicos.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Llamado a la acción -->
        <div class="text-center">
            <p class="text-gray-500 text-sm">Explora los módulos en el menú superior para comenzar a gestionar tu producción.</p>
        </div>
    </div>
</body>
</html>