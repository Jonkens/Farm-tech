<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nosotros | Sistema Ganadero</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .team-card {
            transition: all 0.3s ease;
        }
        .team-card:hover {
            transform: scale(1.02);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body class="bg-gray-50 font-sans">
    <div class="container mx-auto px-6 py-12">
        <!-- Título -->
        <div class="text-center mb-12">
            <h1 class="text-4xl font-extrabold text-gray-800">Sobre Nosotros</h1>
            <div class="w-24 h-1 bg-green-500 mx-auto mt-4 rounded-full"></div>
        </div>

        <!-- Misión y Visión -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div class="bg-white rounded-2xl shadow-md p-8 border-l-8 border-blue-500">
                <div class="flex items-center gap-3 mb-4">
                    <i class="fas fa-bullseye text-3xl text-blue-600"></i>
                    <h2 class="text-2xl font-bold text-gray-800">Misión</h2>
                </div>
                <p class="text-gray-700 leading-relaxed">
                    Brindamos soluciones tecnológicas innovadoras y accesibles que mejoran la vida de los usuarios, ofreciendo servicios de calidad con un enfoque de eficiencia y creatividad.
                </p>
            </div>
            <div class="bg-white rounded-2xl shadow-md p-8 border-l-8 border-green-500">
                <div class="flex items-center gap-3 mb-4">
                    <i class="fas fa-eye text-3xl text-green-600"></i>
                    <h2 class="text-2xl font-bold text-gray-800">Visión</h2>
                </div>
                <p class="text-gray-700 leading-relaxed">
                    Ser una microempresa líder tecnológica, reconocida por crear soluciones de software inteligentes, eficientes y accesibles que transformen la forma en que las organizaciones trabajan, crecen y se conectan en el mundo digital.
                </p>
            </div>
        </div>

        <div class="mb-12">
            <h2 class="text-3xl font-bold text-center text-gray-800 mb-8">Nuestro Equipo</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                <!-- Integrante 1 -->
                <div class="team-card bg-white rounded-xl shadow-md p-5 text-center">
                    <div class="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-3 flex items-center justify-center">
                        <i class="fas fa-user-circle text-5xl text-gray-500"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800">Isaí Enoc Arana Zepeda</h3>   
                    
                </div>
                <!-- Integrante 2 -->
                <div class="team-card bg-white rounded-xl shadow-md p-5 text-center">
                    <div class="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-3 flex items-center justify-center">
                        <i class="fas fa-user-circle text-5xl text-gray-500"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800">Oscar Fransisco Arévalo Palma</h3>
                    
                </div>
                <!-- Integrante 3 -->
                <div class="team-card bg-white rounded-xl shadow-md p-5 text-center">
                    <div class="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-3 flex items-center justify-center">
                        <i class="fas fa-user-circle text-5xl text-gray-500"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800">Jonathan Josué Barrera Martínez</h3>
                    
                </div>
                <!-- Integrante 4 -->
                <div class="team-card bg-white rounded-xl shadow-md p-5 text-center">
                    <div class="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-3 flex items-center justify-center">
                        <i class="fas fa-user-circle text-5xl text-gray-500"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800">Yoselin Abigail Contreras Linares</h3>
                    
                </div>
                <!-- Integrante 5 -->
                <div class="team-card bg-white rounded-xl shadow-md p-5 text-center">
                    <div class="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-3 flex items-center justify-center">
                        <i class="fas fa-user-circle text-5xl text-gray-500"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800">José Mario Mendoza Ramírez</h3>
                    
                </div>
                <!-- Integrante 6 -->
                <div class="team-card bg-white rounded-xl shadow-md p-5 text-center">
                    <div class="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-3 flex items-center justify-center">
                        <i class="fas fa-user-circle text-5xl text-gray-500"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800">Tania Carolina Segura López</h3>
                    
                </div>
                <!-- Integrante 7 -->
                <div class="team-card bg-white rounded-xl shadow-md p-5 text-center">
                    <div class="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-3 flex items-center justify-center">
                        <i class="fas fa-user-circle text-5xl text-gray-500"></i>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800">Lourdes Carolina Contreras Tacón</h3>
                    
                </div>
            </div>
            
        </div>
    </div>
</body>
</html>