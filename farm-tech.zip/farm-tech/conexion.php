<?php
$host = '';         // Servidor de base de datos
$port = '';              // Puerto de PostgreSQL
$dbname = '';   // Nombre de la base de datos
$user = '';        // Usuario
$password = ''; // Contraseña

$dsn = "pgsql:host=$host;port=$port;dbname=$dbname;";

try {
    
    $pdo = new PDO($dsn, $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
]);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch (PDOException $e) {
    
    error_log($e->getMessage());
    die('Error al conectar con la base de datos.');
}
